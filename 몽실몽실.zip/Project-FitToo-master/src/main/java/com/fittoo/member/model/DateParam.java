package com.fittoo.member.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DateParam {

	private Integer prevMonth;
	private Integer nextMonth;
	private Integer year;

}
