package com.fittoo.member.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReservationParam {
    private String trainerId;
}
