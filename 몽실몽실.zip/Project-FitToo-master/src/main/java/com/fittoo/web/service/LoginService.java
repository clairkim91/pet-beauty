package com.fittoo.web.service;

import org.springframework.security.core.userdetails.UserDetailsService;

public interface LoginService extends UserDetailsService {
//    UserDetails loginValid loginSubmit(LoginInput input);
}
