package com.fittoo.web.session;

public abstract class SessionConst {
    public static final String LOGIN_COMPLETE = "loginMember";
}
