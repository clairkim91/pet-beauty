package com.fittoo.trainer.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ScheduleInput {

	private String startDate;
	private String endDate;
	private String comment;

}
